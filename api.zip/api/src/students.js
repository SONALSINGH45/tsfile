const students=[{"id":5,"first_name":"Averil","last_name":"Melato","email":"amelato0@fc2.com"},
{"id":1,"first_name":"Seamus","last_name":"Emblow","email":"semblow1@e-recht24.de"},
{"id":2,"first_name":"Hetty","last_name":"Verdy","email":"hverdy2@i2i.jp"},
{"id":3,"first_name":"Lynette","last_name":"Edeler","email":"ledeler3@google.es"},
{"id":4,"first_name":"Georgie","last_name":"Gilffillan","email":"ggilffillan4@wufoo.com"}]
module.exports=students    